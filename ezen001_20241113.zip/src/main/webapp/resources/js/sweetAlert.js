/**
 * 
 */
 
$(function() {
    $("#cancelBtn").click(function() {
        Swal.fire({
            title: "정말 취소하시겠습니까?",
            text: "작성 중인 내용이 사라질 수 있습니다.",
            icon: "warning",
            showCancelButton: true,
            confirmButtonColor: "#3085d6",
            cancelButtonColor: "#d33",
            confirmButtonText: "예",
            cancelButtonText: "아니오"
        }).then((result) => {
            if (result.isConfirmed) {
                history.back();
            }
        });
    });
});
 