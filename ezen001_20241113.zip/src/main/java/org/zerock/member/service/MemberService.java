package org.zerock.member.service;

import org.zerock.member.vo.LoginVO;

public interface MemberService {

	// 로그인
	public LoginVO login(LoginVO vo);
}
