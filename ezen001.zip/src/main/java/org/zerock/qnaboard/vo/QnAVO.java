package org.zerock.qnaboard.vo;

import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class QnAVO {

	private Long qna_no;
    private String id;
    private String title;
    private String content;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date writeDate;
    private String category;
    
		
	}
