package org.zerock.qnaboard.vo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class AnswerVO {

	private Long answer_no;
    private String id;
    private String answer_title;
    private String answer_content;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date answerDate;
    private Long refNo;
    private Long ordNo;
    private Long levNo;
    private Long parentNo;
	
}
