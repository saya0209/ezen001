package org.zerock.goods.vo;

import lombok.Data;

@Data
public class GoodsSizeVO {

	private Long goods_size_no;
	private String size_name;
	private Long goods_no;
}
